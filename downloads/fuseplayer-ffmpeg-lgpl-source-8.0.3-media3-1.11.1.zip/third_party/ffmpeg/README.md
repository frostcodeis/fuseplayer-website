# FusePlayer FFmpeg audio build

FFmpeg 8.0.3 is built from the signed upstream release without source changes.
The enabled configuration is LGPL-2.1-or-later, not GPL or nonfree.
The separate Media3 1.11.1 Java/JNI bridge is Apache-2.0; its upstream files are unchanged.
See UPSTREAM.json for exact versions, hashes and the AndroidX commit.

## Build

Requirements: Android NDK r30 (30.0.16248370), bash, GNU make, a C11 host compiler,
coreutils, diffutils, pkgconf, sed, awk, tar and xz. Windows: use MSYS2 with the make, gcc, diffutils and pkgconf packages.
No system-wide changes or WSL are necessary. Install NDK for the build host.
For Windows, run from MSYS2 bash (paths below are examples):

```sh
export ANDROID_NDK_HOME=/c/path/to/android-ndk-r30
bash tools/build-ffmpeg-lgpl.sh
```

For Linux/macOS set ANDROID_NDK_HOME to the host's NDK installation.
The script builds arm64-v8a, armeabi-v7a, x86, x86_64 for Android API 24.
An ABI argument restricts the build, e.g. bash tools/build-ffmpeg-lgpl.sh arm64-v8a.
JOBS controls parallel compilation (default 12).
Sources are extracted from sources/ffmpeg-lgpl/ffmpeg-8.0.3.tar.xz after SHA-256 verification.
The exact configure invocation, generated configuration, ELF report and output hashes
are recorded under third_party/ffmpeg/build-info/<ABI>/.

FFmpeg is linked dynamically: libavcodec.so, libavutil.so, libswresample.so are separate
from libffmpegJNI.so. All are packaged in third_party/media3-ffmpeg/src/main/jniLibs/.
No FFmpeg library is statically linked into the proprietary application.
The JNI bridge links its C++ runtime statically to avoid a separate libc++_shared.so.
ELF segments are aligned to 16 KiB.

## Replacing the libraries

Build a modified FFmpeg with the compatible public ABI and enabled decoders.
Replace lib/<ABI>/libavcodec.so, libavutil.so and libswresample.so in a copy of the
APK, then zipalign and sign the modified APK using your own Android signing key.
Installation of a differently signed package may require uninstalling the original;
back up your application data first. The original developer's signing key is not required.
Alternatively rebuild the included Apache-2.0 JNI bridge together with your modified
FFmpeg, retaining the Java native method interface, and replace all four libraries.
The app does not validate these libraries against a developer-only checksum.

On Windows with JDK 21+ (set JAVA_HOME), the included helper preserves uncompressed
native entries and removes obsolete signatures while writing a separate unsigned APK:
```powershell
powershell -ExecutionPolicy Bypass -File tools/Replace-FfmpegLibrary.ps1 -InputApk app.apk -Abi arm64-v8a -Library path/to/libavcodec.so -Destination modified-unsigned.apk
zipalign -P 16 -f 4 modified-unsigned.apk modified-aligned.apk
apksigner sign --ks your-own-key.jks --out modified.apk modified-aligned.apk
```
Repeat replacement for other changed libraries before alignment/signing. Use compatible
ABIs; the helper never changes the input APK. Signing tools are in Android SDK build-tools.

FusePlayer permits modification of these LGPL components and reverse engineering
of the application for debugging such modifications as required by LGPL 2.1 section 6.
This permission does not grant rights to proprietary application sources or branding.

## Distribution

Ship the matching source package alongside each distributed binary, with license texts,
this script, the JNI bridge sources, configuration records and modification instructions.
Host it at the same download location as the APK and link it from the distribution page.
Preparing a local source package is not the same as publishing it for recipients.
Keep package hashes tied to each released APK/AAB. jcifs-ng has separate LGPL obligations.
Before publishing, check that the final EULA preserves the above modification rights.

The original source tarball includes upstream optional GPL files; these are not enabled
or linked by this build. Configuration and binary dependency checks determine this build's license.
