plugins {
    alias(libs.plugins.android.library)
}

group = "com.fuseplayer.thirdparty"
version = "1.11.1-ffmpeg8.0.3-lgpl1"

android {
    namespace = "androidx.media3.decoder.ffmpeg"
    compileSdk = 37
    defaultConfig {
        minSdk = 24
        consumerProguardFiles("consumer-rules.pro")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// Fail explicitly if a checkout is missing native artifacts instead of silently
// losing software decoding on devices without platform support.
val nativeLibraries = listOf("arm64-v8a", "armeabi-v7a", "x86", "x86_64").flatMap { abi ->
    listOf("avcodec", "avutil", "swresample", "ffmpegJNI").map { name ->
        layout.projectDirectory.file("src/main/jniLibs/$abi/lib$name.so").asFile
    }
}
val verifyNativeLibraries = tasks.register("verifyNativeLibraries") {
    val requiredFiles = nativeLibraries.toList()
    inputs.files(requiredFiles)
    doLast {
        check(requiredFiles.all { it.isFile && it.length() > 0 }) {
            "Missing FFmpeg native libraries. Run tools/build-ffmpeg-lgpl.sh; see third_party/ffmpeg/README.md."
        }
    }
}
tasks.named("preBuild").configure { dependsOn(verifyNativeLibraries) }

dependencies {
    api(libs.androidx.media3.decoder)
    implementation(libs.androidx.media3.exoplayer)
    compileOnly("androidx.annotation:annotation:1.9.1")
    compileOnly("org.checkerframework:checker-qual:3.49.5")
}
