Corresponding FFmpeg source and Apache-2.0 Media3 bridge for FusePlayer.
See third_party/ffmpeg/README.md for the exact build and library replacement instructions.
The FFmpeg source tarball is unchanged and its release signature is included.
The proprietary FusePlayer app is not needed to build these replaceable libraries.

Native build: set ANDROID_NDK_HOME and run bash tools/build-ffmpeg-lgpl.sh.
Android AAR build: use JDK 21+, Android SDK platform 37 and run gradlew :media3-ffmpeg:assembleRelease.
Set ANDROID_HOME to your Android SDK, or create your own local.properties with sdk.dir.
This standalone project intentionally contains no signing key or account configuration.
Full FFmpeg LGPL text is inside the source tarball (COPYING.LGPLv2.1).
The Media3 Apache license is third_party/media3-ffmpeg/LICENSE.