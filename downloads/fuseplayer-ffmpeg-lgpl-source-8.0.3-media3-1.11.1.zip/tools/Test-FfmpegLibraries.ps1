param([Parameter(Mandatory=$true)][string]$Ndk)
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$readelf = Join-Path $Ndk "toolchains/llvm/prebuilt/windows-x86_64/bin/llvm-readelf.exe"
$upstream = Get-Content (Join-Path $root "third_party/ffmpeg/UPSTREAM.json") -Raw | ConvertFrom-Json
$libraryNames = @("libavcodec.so","libavutil.so","libswresample.so","libffmpegJNI.so")
$allowedNeeded = @("libavcodec.so","libavutil.so","libswresample.so","libc.so","libm.so","libdl.so","liblog.so","libandroid.so")
foreach ($abi in $upstream.abis) {
    $info = Join-Path $root "third_party/ffmpeg/build-info/$abi"
    $config = Get-Content (Join-Path $info "config.h") -Raw
    foreach ($flag in @("GPL","NONFREE","VERSION3","STATIC")) {
        if ($config -notmatch "(?m)^#define CONFIG_$flag 0$") { throw "$abi has unexpected $flag configuration" }
    }
    if ($config -notmatch '(?m)^#define CONFIG_SHARED 1$') { throw "$abi is not shared" }
    if ($config -notmatch '#define FFMPEG_LICENSE "LGPL version 2.1 or later"') { throw "$abi license mismatch" }
    $components = Get-Content (Join-Path $info "config_components.h") -Raw
    $enabled = @([regex]::Matches($components, '(?m)^#define CONFIG_(\w+)_DECODER 1$') | ForEach-Object { $_.Groups[1].Value.ToLowerInvariant() } | Sort-Object)
    if (@(Compare-Object @($upstream.decoders | Sort-Object) $enabled).Count) { throw "$abi decoder list mismatch" }
    foreach ($libraryName in $libraryNames) {
        $file = Join-Path $root "third_party/media3-ffmpeg/src/main/jniLibs/$abi/$libraryName"
        $report = & $readelf --dynamic --program-headers $file
        if ($LASTEXITCODE) { throw "Invalid ELF: $file" }
        $loads = @($report | Where-Object { $_ -match '^\s*LOAD\s' })
        if (!$loads.Count) { throw "No load segments: $file" }
        foreach ($line in $loads) {
            $alignment = [Convert]::ToInt64(($line.Trim() -split '\s+')[-1].Substring(2), 16)
            if ($alignment -lt 16384) { throw "ELF alignment below 16 KB: $file" }
        }
        $needed = @($report | Where-Object { $_ -match '\(NEEDED\)' } | ForEach-Object { [regex]::Match($_, '\[([^]]+)\]').Groups[1].Value })
        foreach ($dependency in $needed) {
            if ($dependency -notin $allowedNeeded) { throw "Unexpected native dependency $dependency in $file" }
        }
        if ($libraryName -eq "libffmpegJNI.so") {
            foreach ($dependency in @("libavcodec.so","libavutil.so","libswresample.so")) {
                if ($dependency -notin $needed) { throw "FFmpeg is not dynamically linked: $file" }
            }
        } else {
            $binaryText = [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($file))
            if (!$binaryText.Contains("LGPL version 2.1 or later")) { throw "Binary license string mismatch: $file" }
        }
        $hash = (Get-FileHash $file -Algorithm SHA256).Hash.ToLowerInvariant()
        $expected = @(Get-Content (Join-Path $info "SHA256SUMS") | Where-Object { $_ -match ("^[0-9a-f]{64} [ *]" + [regex]::Escape($libraryName) + "$") })
        if ($expected.Count -ne 1 -or ($expected[0] -split " ")[0] -ne $hash) { throw "Recorded native hash mismatch: $file" }
    }
    Write-Output "PASS $abi : LGPL configuration, decoder set, shared linking, hashes, ELF 16 KB"
}
