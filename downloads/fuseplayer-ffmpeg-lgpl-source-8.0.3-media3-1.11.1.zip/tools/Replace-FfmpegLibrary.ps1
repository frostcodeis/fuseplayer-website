param(
    [Parameter(Mandatory=$true)][string]$InputApk,
    [Parameter(Mandatory=$true)][ValidateSet("arm64-v8a","armeabi-v7a","x86","x86_64")][string]$Abi,
    [Parameter(Mandatory=$true)][string]$Library,
    [Parameter(Mandatory=$true)][string]$Destination
)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.IO.Compression.FileSystem
$name = Split-Path $Library -Leaf
if ($name -notin @("libavcodec.so","libavutil.so","libswresample.so","libffmpegJNI.so")) { throw "Not an FFmpeg library" }
if (Test-Path $Destination) { throw "Destination already exists; choose a new output filename" }
$destinationPath = [IO.Path]::GetFullPath($Destination)
$jar = if ($env:JAVA_HOME) { Join-Path $env:JAVA_HOME "bin/jar.exe" } else { "jar.exe" }
$stage = Join-Path (Split-Path $destinationPath -Parent) (".ffmpeg-repack-"+[Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory $stage | Out-Null
try {
    [IO.Compression.ZipFile]::ExtractToDirectory((Resolve-Path $InputApk), $stage)
    $nativePath = Join-Path $stage "lib/$Abi/$name"
    if (!(Test-Path $nativePath)) { throw "APK does not contain lib/$Abi/$name" }
    Copy-Item (Resolve-Path $Library) $nativePath -Force
    # Remove obsolete V1 signatures. Rebuilding also omits the old APK signing block.
    $meta = Join-Path $stage "META-INF"
    if (Test-Path $meta) {
        Get-ChildItem $meta -File | Where-Object { $_.Name -match '([.](RSA|DSA|EC|SF)$|^MANIFEST[.]MF$)' } | Remove-Item
    }
    # jar --no-compress writes STORED ZIP entries. .NET Framework's NoCompression
    # can still write DEFLATED entries, which Android cannot mmap as native code.
    & $jar --create --file $destinationPath --no-compress --no-manifest -C $stage .
    if ($LASTEXITCODE) { throw "JDK jar failed to create the replacement APK" }
} finally { Remove-Item $stage -Recurse -Force }
Write-Output "Created unsigned replacement APK: $Destination"
Write-Output "Run zipalign -P 16 -f 4, then apksigner sign with your own key before installation."
