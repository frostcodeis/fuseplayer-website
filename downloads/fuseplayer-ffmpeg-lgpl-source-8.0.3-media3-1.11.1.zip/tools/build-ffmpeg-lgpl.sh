#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Rebuild the replaceable LGPL audio libraries and Apache-2.0 Media3 JNI bridge.
# Usage: ANDROID_NDK_HOME=/path/to/android-ndk-r30 bash tools/build-ffmpeg-lgpl.sh [ABI...]
set -euo pipefail
export PATH="/usr/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NDK="${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to Android NDK r30}"
case "$(uname -s)" in
  MINGW*|MSYS*) HOST=windows-x86_64; EXE=.exe; NDK="$(cygpath -u "$NDK")" ;;
  Linux*) HOST=linux-x86_64; EXE= ;;
  Darwin*) HOST=darwin-x86_64; EXE= ;;
  *) echo "Unsupported build host" >&2; exit 1 ;;
esac
TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/$HOST/bin"
SRC="$ROOT/.scratch/ffmpeg-8.0.3"
ARCHIVE="$ROOT/sources/ffmpeg-lgpl/ffmpeg-8.0.3.tar.xz"
EXPECTED=6136812ea6d4e68bdba27e33c2a94382711cdf4f8602ffef056ff792bd6f9818
echo "$EXPECTED  $ARCHIVE" | sha256sum --check
grep -q 'Pkg.Revision = 30.0.16248370' "$NDK/source.properties"
if [[ ! -f "$SRC/configure" ]]; then mkdir -p "$ROOT/.scratch"; tar -xf "$ARCHIVE" -C "$ROOT/.scratch"; fi
ABIS=("$@")
if [[ ${#ABIS[@]} -eq 0 ]]; then ABIS=(arm64-v8a armeabi-v7a x86 x86_64); fi
DECODERS=flac,alac,pcm_mulaw,pcm_alaw,mp3,aac,ac3,eac3,dca,mlp,truehd,vorbis,opus,amrnb,amrwb
JOBS="${JOBS:-12}"
for ABI in "${ABIS[@]}"; do
  case "$ABI" in
    arm64-v8a) ARCH=aarch64; TARGET=aarch64-linux-android24; CPU=armv8-a ;;
    armeabi-v7a) ARCH=arm; TARGET=armv7a-linux-androideabi24; CPU=armv7-a ;;
    x86) ARCH=x86; TARGET=i686-linux-android24; CPU=i686 ;;
    x86_64) ARCH=x86_64; TARGET=x86_64-linux-android24; CPU=x86-64 ;;
    *) echo "Unknown ABI $ABI" >&2; exit 1 ;;
  esac
  BUILD="$ROOT/.scratch/ffmpeg-build/$ABI"
  PREFIX="$BUILD/install"
  OUT="$ROOT/third_party/media3-ffmpeg/src/main/jniLibs/$ABI"
  RECORD="$ROOT/third_party/ffmpeg/build-info/$ABI"
  mkdir -p "$BUILD" "$OUT" "$RECORD"
  cd "$BUILD"
  FLAGS=(
    --target-os=android --arch="$ARCH" --cpu="$CPU" --enable-cross-compile
    --cc="$TOOLCHAIN/clang$EXE --target=$TARGET"
    --cxx="$TOOLCHAIN/clang++$EXE --target=$TARGET"
    --ld="$TOOLCHAIN/clang$EXE --target=$TARGET"
    --ar="$TOOLCHAIN/llvm-ar$EXE" --nm="$TOOLCHAIN/llvm-nm$EXE"
    --ranlib="$TOOLCHAIN/llvm-ranlib$EXE" --strip="$TOOLCHAIN/llvm-strip$EXE"
    --prefix="$PREFIX"
    --disable-everything --disable-autodetect --disable-programs --disable-doc
    --disable-debug --disable-network --disable-avformat --disable-avdevice
    --disable-avfilter --disable-swscale --disable-x86asm
    --disable-gpl --disable-nonfree --disable-version3
    --enable-avcodec --enable-avutil --enable-swresample
    --enable-shared --disable-static --enable-pic
    --enable-decoder="$DECODERS"
    --extra-cflags=-fPIC
    "--extra-ldflags=-Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384"
  )
  printf '%q ' "$SRC/configure" "${FLAGS[@]}" > "$RECORD/configure-command.txt"
  printf '\n' >> "$RECORD/configure-command.txt"
  echo "Configuring $ABI"
  "$SRC/configure" "${FLAGS[@]}" > configure-output.txt 2>&1 || { cat configure-output.txt; exit 1; }
  grep -q '#define CONFIG_GPL 0' config.h
  grep -q '#define CONFIG_NONFREE 0' config.h
  grep -q '#define CONFIG_VERSION3 0' config.h
  grep -q '#define FFMPEG_LICENSE "LGPL version 2.1 or later"' config.h
  make -j"$JOBS" > build-output.txt 2>&1 || { tail -100 build-output.txt; exit 1; }
  make install > install-output.txt 2>&1 || { tail -100 install-output.txt; exit 1; }
  cp "$PREFIX/lib/libavcodec.so" "$PREFIX/lib/libavutil.so" "$PREFIX/lib/libswresample.so" "$OUT/"
  "$TOOLCHAIN/clang++$EXE" --target="$TARGET" -std=c++11 -O2 -fPIC -shared \
    -fvisibility=hidden -static-libstdc++ -Wl,--no-undefined \
    -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384 \
    -Wl,-soname,libffmpegJNI.so \
    -I"$PREFIX/include" "$ROOT/third_party/media3-ffmpeg/src/main/jni/ffmpeg_jni.cc" \
    -L"$OUT" -lavcodec -lswresample -lavutil -llog -landroid \
    -o "$OUT/libffmpegJNI.so" > jni-output.txt 2>&1 || { cat jni-output.txt; exit 1; }
  "$TOOLCHAIN/llvm-strip$EXE" --strip-unneeded "$OUT/"*.so
  cp config.h config_components.h configure-output.txt "$RECORD/"
  "$TOOLCHAIN/llvm-readelf$EXE" -d -l "$OUT/"*.so > "$RECORD/elf-report.txt"
  (cd "$OUT"; sha256sum *.so) > "$RECORD/SHA256SUMS"
  echo "Completed $ABI (shared FFmpeg, LGPL 2.1+, 16 KB)"
done
