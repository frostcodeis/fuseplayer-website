pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name = "FusePlayerFfmpegSource"
include(":media3-ffmpeg")
project(":media3-ffmpeg").projectDir = file("third_party/media3-ffmpeg")