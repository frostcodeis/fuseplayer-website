jcifs-ng 2.1.10 corresponding source for FusePlayer 1.0.
The library sources are unmodified. The original source JAR, published Maven POM,
and full upstream tag archive including build files are supplied.
Upstream: https://github.com/AgNO3/jcifs-ng/tree/jcifs-ng-2.1.10
License: LGPL 2.1 (see LICENSE.txt and the upstream archive).
Build from the extracted upstream tree with Maven and a compatible JDK.
The compiled library must retain the public jcifs API used by the app.
Use the companion fuseplayer-1.0-lgpl-relink package to link a modified JAR.
FrostCode's proprietary application source and signing keys are not required.